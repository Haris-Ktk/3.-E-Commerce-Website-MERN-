import { Link } from 'react-router-dom';
import { ArrowLeft, RotateCcw, Package, Clock, CreditCard } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import Layout from '@/components/layout/Layout';

const Returns = () => {
  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center space-x-4 mb-8">
          <Link to="/" className="flex items-center space-x-2 text-muted-foreground hover:text-primary">
            <ArrowLeft className="h-4 w-4" />
            <span>Back to Home</span>
          </Link>
        </div>

        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <RotateCcw className="h-16 w-16 text-primary mx-auto mb-4" />
            <h1 className="font-display text-4xl font-bold mb-4">Returns & Exchanges</h1>
            <p className="text-muted-foreground text-lg">
              We want you to be completely satisfied with your purchase. Here's our hassle-free return policy.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            <Card className="text-center">
              <CardContent className="p-6">
                <Clock className="h-12 w-12 text-primary mx-auto mb-4" />
                <h3 className="font-semibold mb-2">30-Day Window</h3>
                <p className="text-muted-foreground text-sm">
                  Return items within 30 days of delivery for a full refund
                </p>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardContent className="p-6">
                <Package className="h-12 w-12 text-primary mx-auto mb-4" />
                <h3 className="font-semibold mb-2">Free Returns</h3>
                <p className="text-muted-foreground text-sm">
                  We provide free return shipping labels for all eligible returns
                </p>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardContent className="p-6">
                <CreditCard className="h-12 w-12 text-primary mx-auto mb-4" />
                <h3 className="font-semibold mb-2">Fast Refunds</h3>
                <p className="text-muted-foreground text-sm">
                  Refunds processed within 3-5 business days of receiving returns
                </p>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-8">
            <Card>
              <CardHeader>
                <CardTitle>Return Policy</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold mb-2">Eligible Items</h4>
                  <p className="text-muted-foreground mb-4">
                    Most items can be returned within 30 days of delivery. Items must be:
                  </p>
                  <ul className="space-y-2 text-muted-foreground">
                    <li>• In original condition and packaging</li>
                    <li>• Unworn, unused, and undamaged</li>
                    <li>• Include all original tags and accessories</li>
                    <li>• Accompanied by the original receipt or order confirmation</li>
                  </ul>
                </div>
                
                <div>
                  <h4 className="font-semibold mb-2 flex items-center space-x-2">
                    <span>Non-Returnable Items</span>
                    <Badge variant="destructive">Exceptions</Badge>
                  </h4>
                  <ul className="space-y-2 text-muted-foreground">
                    <li>• Personalized or customized items</li>
                    <li>• Perishable goods</li>
                    <li>• Digital downloads</li>
                    <li>• Gift cards</li>
                    <li>• Final sale items</li>
                  </ul>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>How to Return an Item</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="flex items-start space-x-4">
                    <div className="flex-shrink-0 w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center font-semibold">
                      1
                    </div>
                    <div>
                      <h4 className="font-semibold mb-2">Start Your Return</h4>
                      <p className="text-muted-foreground">
                        Contact our customer service team at support@devshop.com or call +92 300 7654321 to initiate your return.
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-4">
                    <div className="flex-shrink-0 w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center font-semibold">
                      2
                    </div>
                    <div>
                      <h4 className="font-semibold mb-2">Get Your Return Label</h4>
                      <p className="text-muted-foreground">
                        We'll email you a prepaid return shipping label within 24 hours.
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-4">
                    <div className="flex-shrink-0 w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center font-semibold">
                      3
                    </div>
                    <div>
                      <h4 className="font-semibold mb-2">Pack and Ship</h4>
                      <p className="text-muted-foreground">
                        Package your item securely, attach the return label, and drop it off at any authorized shipping location.
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-4">
                    <div className="flex-shrink-0 w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center font-semibold">
                      4
                    </div>
                    <div>
                      <h4 className="font-semibold mb-2">Get Your Refund</h4>
                      <p className="text-muted-foreground">
                        Once we receive and process your return, we'll issue a refund to your original payment method within 3-5 business days.
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Exchanges</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">
                  We currently don't offer direct exchanges. To exchange an item:
                </p>
                <ol className="space-y-2 text-muted-foreground">
                  <li>1. Return your original item following the return process above</li>
                  <li>2. Place a new order for the item you want</li>
                  <li>3. Once we process your return, you'll receive a full refund</li>
                </ol>
                <p className="text-muted-foreground mt-4">
                  This ensures you get the item you want as quickly as possible!
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Damaged or Defective Items</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">
                  If you receive a damaged or defective item, please contact us immediately at support@devshop.com with:
                </p>
                <ul className="space-y-2 text-muted-foreground">
                  <li>• Your order number</li>
                  <li>• Photos of the damaged item</li>
                  <li>• Description of the issue</li>
                </ul>
                <p className="text-muted-foreground mt-4">
                  We'll provide a replacement or full refund, and you won't need to return the damaged item.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Questions?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">
                  Our customer service team is here to help with any return questions:
                </p>
                <div className="space-y-2 text-muted-foreground">
                  <p>Email: support@devshop.com</p>
                  <p>Phone: +92 300 7654321</p>
                  <p>Live Chat: Available 9 AM - 6 PM (Monday-Friday)</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Returns;