import { Link } from 'react-router-dom';
import { Heart, ShoppingCart, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Layout from '@/components/layout/Layout';
import ProductCard from '@/components/product/ProductCard';
import { useWishlist } from '@/contexts/WishlistContext';
import { useCart } from '@/contexts/CartContext';

const Wishlist = () => {
  const { items: wishlistItems, clearWishlist } = useWishlist();
  const { addToCart } = useCart();

  const handleAddAllToCart = () => {
    wishlistItems.forEach(item => {
      addToCart(item);
    });
  };

  if (wishlistItems.length === 0) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-16">
          <div className="text-center space-y-6 max-w-md mx-auto">
            <div className="w-24 h-24 bg-muted rounded-full flex items-center justify-center mx-auto">
              <Heart className="h-12 w-12 text-muted-foreground" />
            </div>
            <h1 className="font-display text-2xl font-bold">Your Wishlist is Empty</h1>
            <p className="text-muted-foreground">
              You haven't saved any products yet. Start shopping and add items you love to your wishlist!
            </p>
            <Link to="/shop">
              <Button size="lg" className="btn-gradient">
                Start Shopping
              </Button>
            </Link>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center space-x-4 mb-8">
          <Link to="/shop" className="flex items-center space-x-2 text-muted-foreground hover:text-primary">
            <ArrowLeft className="h-4 w-4" />
            <span>Continue Shopping</span>
          </Link>
        </div>

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
          <div className="flex items-center space-x-4">
            <Heart className="h-8 w-8 text-primary" />
            <h1 className="font-display text-3xl font-bold">My Wishlist</h1>
            <span className="text-muted-foreground">({wishlistItems.length} items)</span>
          </div>
          
          <div className="flex space-x-3">
            <Button
              variant="outline"
              onClick={clearWishlist}
              className="flex items-center space-x-2"
            >
              <Heart className="h-4 w-4" />
              <span>Clear All</span>
            </Button>
            <Button
              onClick={handleAddAllToCart}
              className="btn-gradient flex items-center space-x-2"
            >
              <ShoppingCart className="h-4 w-4" />
              <span>Add All to Cart</span>
            </Button>
          </div>
        </div>

        {/* Wishlist Items */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {wishlistItems.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </div>
    </Layout>
  );
};

export default Wishlist;