import { Users, Target, Heart, Award } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import Layout from '@/components/layout/Layout';
import { teamMembers } from '@/data/products';

const About = () => {
  const values = [
    {
      icon: Target,
      title: 'Our Mission',
      description: 'To provide top-quality products with exceptional service, making online shopping simple and enjoyable.',
    },
    {
      icon: Heart,
      title: 'Customer First',
      description: 'Every decision we make puts our customers at the center, ensuring the best shopping experience.',
    },
    {
      icon: Award,
      title: 'Quality Assurance',
      description: 'We carefully curate our products to ensure only the highest quality items reach our customers.',
    },
    {
      icon: Users,
      title: 'Community',
      description: 'Building a community of satisfied customers who trust us for their shopping needs.',
    },
  ];

  const stats = [
    { label: 'Happy Customers', value: '10,000+' },
    { label: 'Products Sold', value: '50,000+' },
    { label: 'Countries Served', value: '25+' },
    { label: 'Team Members', value: '50+' },
  ];

  return (
    <Layout>
      {/* Hero Section */}
      <section className="py-20 bg-gradient-primary text-white">
        <div className="container mx-auto px-4 text-center">
          <div className="max-w-3xl mx-auto space-y-6">
            <h1 className="font-display text-4xl md:text-5xl font-bold">About DevShop</h1>
            <p className="text-lg text-blue-100 leading-relaxed">
              At DevShop, we aim to provide top-quality products with excellent service. 
              Our goal is to make online shopping simple, convenient, and enjoyable for everyone.
            </p>
          </div>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div className="space-y-6">
                <h2 className="font-display text-3xl font-bold">Our Story</h2>
                <div className="space-y-4 text-muted-foreground leading-relaxed">
                  <p>
                    Founded in 2020, DevShop started as a small team with a big vision: to revolutionize 
                    the online shopping experience. We noticed that customers were looking for a platform 
                    that combined quality products, competitive prices, and exceptional service.
                  </p>
                  <p>
                    Today, we've grown into a trusted e-commerce destination serving thousands of customers 
                    worldwide. Our commitment to excellence has never wavered, and we continue to expand 
                    our product range while maintaining the personal touch that sets us apart.
                  </p>
                  <p>
                    Every product in our catalog is carefully selected to meet our high standards for 
                    quality and value. We believe that great products should be accessible to everyone, 
                    and we're proud to make that vision a reality every day.
                  </p>
                </div>
              </div>
              <div className="relative">
                <div className="aspect-square bg-gradient-card rounded-2xl p-8 flex items-center justify-center">
                  <div className="text-center space-y-4">
                    <div className="w-20 h-20 bg-gradient-primary rounded-full flex items-center justify-center mx-auto mb-4">
                      <span className="text-white font-bold text-2xl">D</span>
                    </div>
                    <h3 className="font-display text-xl font-bold">DevShop</h3>
                    <p className="text-muted-foreground">Since 2020</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center space-y-4 mb-12">
            <h2 className="font-display text-3xl font-bold">Our Values</h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              These core values guide everything we do and shape the way we serve our customers.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map((value, index) => {
              const Icon = value.icon;
              return (
                <Card key={index} className="text-center border-0 bg-background/50 backdrop-blur-sm">
                  <CardContent className="pt-8 pb-6 space-y-4">
                    <div className="w-16 h-16 mx-auto bg-gradient-primary rounded-full flex items-center justify-center">
                      <Icon className="h-8 w-8 text-white" />
                    </div>
                    <h3 className="font-display font-semibold text-lg">{value.title}</h3>
                    <p className="text-muted-foreground text-sm leading-relaxed">{value.description}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center space-y-4 mb-12">
            <h2 className="font-display text-3xl font-bold">Our Impact</h2>
            <p className="text-muted-foreground text-lg">
              Numbers that showcase our commitment to excellence
            </p>
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center space-y-2">
                <div className="text-3xl md:text-4xl font-display font-bold text-primary">
                  {stat.value}
                </div>
                <div className="text-muted-foreground font-medium">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>
{/* Team Section */}
<section className="py-16 bg-muted/30">
  <div className="container mx-auto px-4">
    <div className="text-center space-y-4 mb-12">
      <h2 className="font-display text-3xl font-bold">Meet Our Team</h2>
      <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
        The passionate people behind DevShop who work tirelessly to serve you better.
      </p>
    </div>

    <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
      {[
        {
          id: 1,
          name: "Sarah Johnson",
          role: "CEO & Founder",
          bio: "Leads DevShop with a vision for innovation and customer-first service.",
          image: "https://images.unsplash.com/photo-1607746882042-944635dfe10e?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
        },
        {
          id: 2,
          name: "Michael Lee",
          role: "Lead Developer",
          bio: "Passionate about building scalable web applications and leading the dev team.",
          image: "https://images.unsplash.com/photo-1599566150163-29194dcaad36?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
        },
        {
          id: 3,
          name: "Emily Davis",
          role: "Marketing Head",
          bio: "Crafts creative campaigns and drives the brand presence of DevShop worldwide.",
          image: "https://images.unsplash.com/photo-1544723795-3fb6469f5b39?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
        },
      ].map((member) => (
        <Card key={member.id} className="text-center overflow-hidden">
          <div className="aspect-square overflow-hidden bg-muted">
            <img
              src={member.image}
              alt={member.name}
              className="w-full h-full object-cover"
              loading="lazy"
            />
          </div>
          <CardContent className="p-6 space-y-3">
            <h3 className="font-display font-semibold text-lg">{member.name}</h3>
            <p className="text-primary font-medium">{member.role}</p>
            <p className="text-muted-foreground text-sm leading-relaxed">{member.bio}</p>
          </CardContent>
        </Card>
      ))}
    </div>
  </div>
</section>


      {/* CTA Section */}
      <section className="py-20 bg-gradient-primary text-white">
        <div className="container mx-auto px-4 text-center">
          <div className="max-w-2xl mx-auto space-y-6">
            <h2 className="font-display text-3xl md:text-4xl font-bold">Join Our Journey</h2>
            <p className="text-lg text-blue-100">
              Be part of our growing community and discover amazing products with exceptional service.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a href="/shop" className="inline-block">
                <div className="px-8 py-3 bg-white text-primary font-medium rounded-lg hover:bg-blue-50 transition-colors">
                  Shop Now
                </div>
              </a>
              <a href="/contact" className="inline-block">
                <div className="px-8 py-3 border-2 border-white text-white font-medium rounded-lg hover:bg-white/10 transition-colors">
                  Contact Us
                </div>
              </a>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default About;