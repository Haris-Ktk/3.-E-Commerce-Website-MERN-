import { Product } from '@/components/product/ProductCard';

// Import product images
import smartwatchImg from '@/assets/smartwatch.jpg';
import headphonesImg from '@/assets/headphones.jpg';
import officeChairImg from '@/assets/office-chair.jpg';
import gamingLaptopImg from '@/assets/gaming-laptop.jpg';
import bluetoothSpeakerImg from '@/assets/bluetooth-speaker.jpg';
import fitnessTrackerImg from '@/assets/fitness-tracker.jpg';

export const featuredProducts: Product[] = [
  {
    id: 'smartwatch-x100',
    name: 'SmartWatch X100',
    price: 149.99,
    originalPrice: 199.99,
    image: smartwatchImg,
    rating: 4.5,
    reviewCount: 128,
    category: 'Electronics',
    isNew: true,
    isSale: true,
  },
  {
    id: 'wireless-headphones-pro',
    name: 'Wireless Headphones Pro',
    price: 99.99,
    originalPrice: 129.99,
    image: headphonesImg,
    rating: 4.8,
    reviewCount: 256,
    category: 'Electronics',
    isSale: true,
  },
  {
    id: 'ergonomic-office-chair',
    name: 'Ergonomic Office Chair',
    price: 199.99,
    image: officeChairImg,
    rating: 4.3,
    reviewCount: 89,
    category: 'Home',
  },
  {
    id: 'gaming-laptop-ultra',
    name: 'Gaming Laptop Ultra',
    price: 1299.99,
    originalPrice: 1499.99,
    image: gamingLaptopImg,
    rating: 4.7,
    reviewCount: 45,
    category: 'Electronics',
    isNew: true,
    isSale: true,
  },
  {
    id: 'bluetooth-speaker-mini',
    name: 'Bluetooth Speaker Mini',
    price: 49.99,
    image: bluetoothSpeakerImg,
    rating: 4.2,
    reviewCount: 178,
    category: 'Electronics',
  },
  {
    id: 'fitness-tracker-plus',
    name: 'Fitness Tracker Plus',
    price: 79.99,
    originalPrice: 99.99,
    image: fitnessTrackerImg,
    rating: 4.4,
    reviewCount: 203,
    category: 'Fitness',
    isSale: true,
  },
];

// Additional products for the shop page
export const allProducts: Product[] = [
  ...featuredProducts,
  // Add more products for a full catalog
  {
    id: 'wireless-mouse',
    name: 'Wireless Gaming Mouse',
    price: 39.99,
    originalPrice: 59.99,
    image: smartwatchImg, // Placeholder - would be mouse image
    rating: 4.6,
    reviewCount: 134,
    category: 'Electronics',
    isSale: true,
  },
  {
    id: 'mechanical-keyboard',
    name: 'Mechanical Gaming Keyboard',
    price: 89.99,
    image: headphonesImg, // Placeholder - would be keyboard image
    rating: 4.5,
    reviewCount: 92,
    category: 'Electronics',
  },
  {
    id: 'phone-case',
    name: 'Premium Phone Case',
    price: 24.99,
    originalPrice: 34.99,
    image: officeChairImg, // Placeholder - would be phone case image
    rating: 4.1,
    reviewCount: 267,
    category: 'Accessories',
    isSale: true,
  },
  {
    id: 'tablet-stand',
    name: 'Adjustable Tablet Stand',
    price: 19.99,
    image: gamingLaptopImg, // Placeholder - would be tablet stand image
    rating: 4.3,
    reviewCount: 156,
    category: 'Accessories',
  },
  {
    id: 'desk-lamp',
    name: 'LED Desk Lamp',
    price: 34.99,
    originalPrice: 49.99,
    image: bluetoothSpeakerImg, // Placeholder - would be desk lamp image
    rating: 4.4,
    reviewCount: 98,
    category: 'Home',
    isSale: true,
  },
  {
    id: 'yoga-mat',
    name: 'Premium Yoga Mat',
    price: 29.99,
    image: fitnessTrackerImg, // Placeholder - would be yoga mat image
    rating: 4.7,
    reviewCount: 188,
    category: 'Fitness',
    isNew: true,
  },
];

export const categories = [
  'All',
  'Electronics',
  'Fashion',
  'Home',
  'Fitness',
  'Accessories',
];

export const productReviews = {
  'smartwatch-x100': [
    {
      id: '1',
      author: 'Sarah J.',
      rating: 5,
      comment: 'Excellent quality and fast shipping!',
      date: '2025-01-15',
    },
    {
      id: '2',
      author: 'Ahmed K.',
      rating: 4,
      comment: 'Loved it! Highly recommended.',
      date: '2025-01-10',
    },
    {
      id: '3',
      author: 'Emily C.',
      rating: 5,
      comment: 'Good value for money.',
      date: '2025-01-08',
    },
  ],
  // Add reviews for other products...
};

export const teamMembers = [
  {
    id: '1',
    name: 'Sarah Johnson',
    role: 'CEO',
    image: smartwatchImg, // Placeholder - would be team member photo
    bio: 'Passionate about bringing quality products to customers worldwide.',
  },
  {
    id: '2',
    name: 'Ahmed Khan',
    role: 'Operations Manager',
    image: headphonesImg, // Placeholder - would be team member photo
    bio: 'Ensuring smooth operations and excellent customer service.',
  },
  {
    id: '3',
    name: 'Emily Carter',
    role: 'Marketing Lead',
    image: officeChairImg, // Placeholder - would be team member photo
    bio: 'Creating engaging experiences and building our brand.',
  },
];